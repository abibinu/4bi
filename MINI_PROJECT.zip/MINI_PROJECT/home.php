<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>THE FIND</title>
        <link rel="icon" href="image/logo.png" type="image/png">
        <link rel="stylesheet" type="text/css" href="homestyle.css">
    </head>
    <body>
        <section id="header">
            <a href="#"> <img id="headlogo" src="image/logo.png" type="image/png"> </a>
            <ul id="navbar">
                <li><a class="active" href="">HOME</a></li>
                <li><a href="products.php">PRODUCTS</a></li>
                <li><a href="">ABOUT</a></li>
                <li><a href="">CONTACT</a></li>
                <li><a href="insert.php"> <img id="acclogo" src="image/account.png" type="image/png"> </a></li>
            </ul>
        </section>
        <section id="hero">
                <h1 style="font-size: 70px; color: transparent;">dydyd</h1>
                <h4 id="greeting"></h4>
                <h3 id="step1" style="margin-left: 50px;transform: translate(0px,20px);">STEP-UP</h3>
                <h2 id="step2" style="margin-top: 0%;  transform: translate(7px,-5px);">YOUR</h2>
                <h1 id="step3" style="margin-top: 0%; transform: translate(5px,-55px);">STYLE GAME!</h1>
                <h3 id="dest"> -THE FIND- is your destination for the latest trends and timeless classics!</h3>  
        </section>
        <section id="view">
            <center><a href="products.php"><input id="viewbt" type="button" value="ALL PRODUCTS"></a><br></center>
        </section>
        <footer id="foot">
           <p id="copy"> © 2021 The Find. All rights reserved. <a href="#" style="text-decoration: none;">Privacy Policy</a></p>
        </footer>
        <script>
            const greetingElement = document.getElementById("greeting");
        
            const currentHour = new Date().getHours();
        
            let greetingMessage;
        
            if (currentHour < 12) {
              greetingMessage = "Hello, Good morning!";
            } else if (currentHour < 18) {
              greetingMessage = "Hello, Good afternoon!";
            } else {
              greetingMessage = "Hello, Good evening!";
            }
        
            greetingElement.textContent = greetingMessage;
          </script>
        
    </body>
</html>
