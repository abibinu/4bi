<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <title>THE FIND</title>
        <link rel="icon" href="image/logo.png" type="image/png">
        <link rel="stylesheet" type="text/css" href="productstyle.css">
    </head>
    <body>
        <section id="header">
            <a href="#"> <img id="headlogo" src="image/logo.png" type="image/png"> </a>
            <ul id="navbar">
                <li><a href="home.php">HOME</a></li>
                <li><a class="active" href="">PRODUCTS</a></li>
                <li><a href="">ABOUT</a></li>
                <li><a href="">CONTACT</a></li>
                <li><a href="insert.php"> <img id="acclogo" src="image/account.png" type="image/png"> </a></li>
            </ul>
        </section>
        <section id="hero">
            <h1 style="font-size: 70px; color: transparent;">dydyd</h1>
        </section>
        <center>
        <section class="searchsec">
            <form method="post" class="searchform">
                <div class="container">
                    <input name="search" type="text" placeholder="Search for shoes..." class="searchbar">
                    <button name="searchbtn" class="searchbtn" type="submit">Search</button>
                </div>
            </form>
        </section>
        </center>
    </body>
</html>

<?php

    $conn = mysqli_connect("localhost","root","","miniproject");
        
    if(!$conn){
        die("Not Connected");
    }

    if(isset($_POST["searchbtn"])){
        $search = $_POST["search"];
        $sql = "SELECT * FROM product_details WHERE name LIKE '%".$search."%'";
    }else{
        $sql = "SELECT * FROM product_details ORDER BY name ASC";
    }
    
    $res = mysqli_query($conn,$sql);

    echo "<div class='product-grid'>";
        if (mysqli_num_rows($res) > 0) {
            while($row = mysqli_fetch_assoc($res)){

                echo "<a class='productlink' href=''> <div class='productdisplay'>";
                echo "<img class='image' src='image/" . $row["image"] . "' alt='" . $row["name"] . "'>";
                echo "<h3 class='name'>" . $row["name"] . "</h3>";
                echo "<p class='brand'>" . $row["brand"] . "</p>";

                if($row["stock_quantity"] <= 0){
                    echo "<p class='outofstock'>Out of Stock</p>";
                }elseif ($row["stock_quantity"] == 1) {
                    echo "<p class='outofstock'>Only 1 Stock Left</p>";
                }elseif($row["stock_quantity"] < 5){
                    echo "<p class='outofstock'>Only " . $row["stock_quantity"] . " Stocks Left</p>";
                }else{
                    echo "<p class='instock'>In Stock</p>";
                }

                echo "<p class='price'>MRP: ₹" . $row["price"] . "</p>";

                echo "</div> </a>";
            }
        } else {
        echo "No products found.";
        }

    echo "</div>";

?>